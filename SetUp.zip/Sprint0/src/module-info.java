/**
 * 
 */
/**
 * 
 */
module Sprint0 {
	requires java.desktop;
	requires java.sql;
}